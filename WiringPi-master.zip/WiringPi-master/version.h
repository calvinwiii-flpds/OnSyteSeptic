#define VERSION "3.4"
#define VERSION_MAJOR 3
#define VERSION_MINOR 4
