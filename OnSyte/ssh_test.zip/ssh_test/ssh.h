#pragma once

#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include "libssh.h"

int verify_knownhost(ssh_session session);
int show_remote_processes(ssh_session session);
int scp_receive(ssh_session session, ssh_scp scp);
int scp_read(ssh_session session);
